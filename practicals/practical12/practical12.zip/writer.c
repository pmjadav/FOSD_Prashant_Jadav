#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ipc.h>
#include <sys/shm.h>

#define SHM_SIZE 1024

int main() {
    key_t key;
    int shmid;
    char *shared_memory;

    // Generate a key
    key = ftok("shmfile", 65);

    // Create shared memory segment
    shmid = shmget(key, SHM_SIZE, 0666 | IPC_CREAT);

    if (shmid == -1) {
        perror("shmget");
        exit(1);
    }

    // Attach shared memory
    shared_memory = (char *)shmat(shmid, NULL, 0);

    if (shared_memory == (char *)-1) {
        perror("shmat");
        exit(1);
    }

    // Write string to shared memory
    printf("Enter a string: ");
    fgets(shared_memory, SHM_SIZE, stdin);

    printf("String written to shared memory.\n");

    // Detach shared memory
    shmdt(shared_memory);

    return 0;
}

