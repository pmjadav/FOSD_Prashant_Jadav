#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

#define SIZE 1000
#define THREADS 4

int numbers[SIZE];

typedef struct {
    int thread_id;
    int start;
    int end;
} ThreadData;

void *find_max(void *arg)
{
    ThreadData *data = (ThreadData *)arg;

    int max = numbers[data->start];

    for (int i = data->start + 1; i < data->end; i++) {
        if (numbers[i] > max)
            max = numbers[i];
    }

    /* Allocate memory for result */
    int *result = malloc(sizeof(int));

    *result = max;

    pthread_exit(result);
}

int main()
{
    pthread_t threads[THREADS];
    ThreadData td[THREADS];

    /* Generate sample data */
    srand(100);

    for (int i = 0; i < SIZE; i++) {
        numbers[i] = rand() % 10000;
    }

    /* Create 4 threads */
    int chunk = SIZE / THREADS;

    for (int i = 0; i < THREADS; i++) {
        td[i].thread_id = i;
        td[i].start = i * chunk;
        td[i].end = (i == THREADS - 1) ? SIZE : (i + 1) * chunk;

        pthread_create(&threads[i], NULL, find_max, &td[i]);
    }

    /* Wait for all threads */
    for (int i = 0; i < THREADS; i++) {
        pthread_join(threads[i], NULL);
    }

    /* Find overall maximum */
    int global_max = -1;

    /* Collect thread return values */
    for (int i = 0; i < THREADS; i++)
    {
        void *status;

        pthread_join(threads[i], &status);

        int *local_max = (int *)status;

        printf("Main received %d from thread %d\n", *local_max, i);

        if (*local_max > global_max)
            global_max = *local_max;

        free(local_max);
    }

    printf("Maximum value = %d\n", global_max);

    return 0;
}

