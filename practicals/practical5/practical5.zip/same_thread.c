#include <stdio.h>
#include <pthread.h>

void *worker(void *arg)
{
    pthread_t self = pthread_self();

    if (pthread_equal(self, *(pthread_t *)arg))
        printf("Same thread\n");
    else
        printf("Different thread\n");

    return NULL;
}

int main()
{
    pthread_t tid;

    pthread_create(&tid, NULL, worker, &tid);

    pthread_join(tid, NULL);

    return 0;
}

