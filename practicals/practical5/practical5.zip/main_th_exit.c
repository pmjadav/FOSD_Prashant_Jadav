#include <stdio.h>
#include <pthread.h>
#include <unistd.h>

void *worker(void *arg)
{
    sleep(3);
    printf("Worker finished\n");
    return NULL;
}

int main()
{
    pthread_t tid;

    pthread_create(&tid, NULL, worker, NULL);

    printf("Main thread exiting\n");

    pthread_exit(NULL);
}

