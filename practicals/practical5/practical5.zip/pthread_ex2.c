#include <stdio.h>
#include <pthread.h>
#include <unistd.h>
#include <sys/syscall.h>

void* worker(void* arg) {

    pid_t pid = getpid();

    // Linux kernel thread ID
    pid_t tid = syscall(SYS_gettid);

    printf("Thread started: PID = %d, TID = %d\n", pid, tid);

    sleep(30);

    return NULL;
}

int main() {

    pthread_t t1, t2, t3;

    printf("Main Process PID = %d\n", getpid());

    pthread_create(&t1, NULL, worker, NULL);
    pthread_create(&t2, NULL, worker, NULL);
    pthread_create(&t3, NULL, worker, NULL);

    pthread_join(t1, NULL);
    pthread_join(t2, NULL);
    pthread_join(t3, NULL);

    return 0;
}
/*
pmj@charusat:~/os/thread$ ps -eLf | grep pthread_ex2
pmj         3846     361    3846  0    4 10:14 pts/0    00:00:00 ./pthread_ex2
pmj         3846     361    3848  0    4 10:14 pts/0    00:00:00 ./pthread_ex2
pmj         3846     361    3849  0    4 10:14 pts/0    00:00:00 ./pthread_ex2
pmj         3846     361    3850  0    4 10:14 pts/0    00:00:00 ./pthread_ex2

$top -H

*/
