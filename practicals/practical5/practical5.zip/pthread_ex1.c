#include <stdio.h>
#include <pthread.h>

void* myfunc(void* arg) {
    printf("Thread is running\n");
    return NULL;
}

int main() {
    pthread_t tid;

    pthread_create(&tid, NULL, myfunc, NULL);
    // thread_id, default attributes, thread function, argument to thread function

    pthread_join(tid, NULL);

    printf("Thread finished\n");

    return 0;
}

