#include <stdio.h>
#include <pthread.h>
#include <unistd.h>

void *worker(void *arg)
{
    sleep(5);
    printf("Worker finished\n");
    return NULL;
}

int main()
{
    pthread_t tid;

    pthread_create(&tid, NULL, worker, NULL);

    printf("Waiting for worker...\n");

    pthread_join(tid, NULL);

    printf("Join returned\n");

    return 0;
}
