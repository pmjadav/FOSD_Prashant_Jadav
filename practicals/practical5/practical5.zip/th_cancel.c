#include <stdio.h>
#include <pthread.h>
#include <unistd.h>

void *worker(void *arg)
{
    int i = 1;

    while (1)
    {
        printf("Worker running... %d\n", i++);
        sleep(1);   // Cancellation point
    }

    return NULL;
}

int main()
{
    pthread_t tid;
    void *status;

    pthread_create(&tid, NULL, worker, NULL);

    sleep(5);

    printf("\nMain: Cancelling worker thread...\n");

    pthread_cancel(tid);

    pthread_join(tid, &status);

    if (status == PTHREAD_CANCELED)
    {
        printf("Thread was cancelled\n");
    }
    
    return 0;
}
/*
Common cancellation points:
---------------------------
    sleep()
    read()
    write()
    accept()
    pthread_cond_wait()
    pthread_join()
*/

