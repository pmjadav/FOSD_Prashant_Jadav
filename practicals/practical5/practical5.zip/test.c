#include <unistd.h>
#include <stdio.h>
#include <sys/types.h>

#include <sys/wait.h>

int main()
{

	pid_t p1, p2;

	p1 = fork();

	if (p1 == 0) {

		p2 = fork();

		if (p2 == 0) {

			printf("\nHELLO\n");

			execlp("/bin/eco", "eco", "PRINT", NULL);
			printf("\nDONE\n");

		}

		else {

			wait(NULL);

			printf("\nFINISH\n");

		}

	}

	else {

		wait(NULL);

		execlp("/bin/echo", "echo", "OS", NULL);

		printf("\nEXIT\n");

	}

	return 0;

}
