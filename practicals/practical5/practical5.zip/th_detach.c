#include <stdio.h>
#include <pthread.h>
#include <unistd.h>

void *worker(void *arg)
{
    printf("Worker started\n");

    sleep(2);

    printf("Worker finished\n");

    return NULL;
}
/*
Thread Attributes
---------------------
1) Detach state
2) Stack size
3) Scheduling policy
4) Scheduling priority
*/

int main()
{
    pthread_t tid;
    pthread_attr_t attr;

    pthread_attr_init(&attr);

    pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);

    pthread_create(&tid, &attr, worker, NULL);

    pthread_attr_destroy(&attr); // destroy attribute object

    sleep(5);

    printf("Main exiting\n");
    // No pthread_join() required
    // Thread resources are automatically reclaimed for detached thread

    return 0;
}

