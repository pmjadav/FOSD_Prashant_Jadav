#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>

int main() {
    char msg[] = "Hello through FIFO";

    // Open FIFO for writing
    int fd = open("/tmp/myfifo", O_WRONLY);

    // Write message
    write(fd, msg, strlen(msg) + 1);

    close(fd);

    return 0;
}

