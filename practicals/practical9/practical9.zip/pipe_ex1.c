#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>

int main() {
    int fd[2];  // To store pipe descriptors
    pid_t pid;
    char write_msg[] = "Hello from Parent";
    char read_msg[100];

    // Create pipe
    pipe(fd);
    // fd[0] - Read end
    // fd[1] - Write end

    // Create child process
    pid = fork();
    // Child process inherits pipe descriptiors

    if (pid > 0) {
        // Parent Process - Producer

        close(fd[0]); // Close unused read end

        write(fd[1], write_msg, strlen(write_msg) + 1);
        // +1 to include NULL terminator '\0' of the string message

        close(fd[1]); // Close write end
    }
    else if (pid == 0) {
        // Child Process - Consumer

        close(fd[1]); // Close unused write end

        read(fd[0], read_msg, sizeof(read_msg));

        printf("Child received: %s\n", read_msg);

        close(fd[0]); // Close read end
    }
    else {
        printf("Fork failed\n");
    }

    return 0;
}

