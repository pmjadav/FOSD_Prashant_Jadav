#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>

int main() {
    char buffer[100];

    // Create FIFO
    mkfifo("/tmp/myfifo", 0666);

    // Open FIFO for reading
    int fd = open("/tmp/myfifo", O_RDONLY);

    // Read data
    read(fd, buffer, sizeof(buffer));

    printf("Received: %s\n", buffer);

    close(fd);

    return 0;

    // To view the named pipe:
    // ls -l /tmp/myfifo

    // To remove named pipe (FIFO) from the file system:
    // unlink("/tmp/myfifo");

    // or on the terminal:
    // rm /tmp/myfifo
}

