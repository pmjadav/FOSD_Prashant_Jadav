#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

int main() {
    pid_t pid = fork();

    /*if (pid < 0) {
        perror("fork failed");
        return 1;
    }*/

    if (pid == 0) {
        // Child process
        printf("Child: PID = %d\n", getpid());

        printf("Child: Working for 5 seconds...\n");
        sleep(5);

        printf("Child: Finished.\n");
        exit(10);          // Exit status = 10
    }
    else {
        // Parent process
        int status;

        //printf("Parent: Waiting for child...\n");

        wait(&status);

        printf("Parent: Child completed.\n");

        if (WIFEXITED(status)) {
            printf("Child exited normally.\n");
            printf("Exit Status = %d\n", WEXITSTATUS(status));
        }
    }

    return 0;
}
