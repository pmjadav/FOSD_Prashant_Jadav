#include <stdio.h>
#include <unistd.h>

int main()
{
    printf("hello1\n");
    fork();
    printf("pid = %d\n", getpid());
}

