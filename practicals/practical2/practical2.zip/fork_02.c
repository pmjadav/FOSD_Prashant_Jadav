#include <stdio.h>
#include <unistd.h>

int main()
{
    pid_t pid;

    pid = fork();
    if (pid == 0) { // child process
        printf("CHILD: \n");
        printf("Child: my pid: %d\n", getpid());
    }
    else {           // parent process
        printf("PARENT: \n");
        printf("Parent: Child pid %d\n", pid);
        printf("Parent: my pid %d\n", getpid());
    }
}

