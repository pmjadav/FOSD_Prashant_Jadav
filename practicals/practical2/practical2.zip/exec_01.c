#include <stdio.h>
#include <unistd.h>

int main() {
    printf("Before exec()\n");

    execl("/bin/ls", "ls", "-l", NULL);

    // This line executes only if exec() fails
    perror("execl failed");

    return 1;
}
