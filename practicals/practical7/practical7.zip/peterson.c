#include <stdio.h>
#include <pthread.h>

#define ITERATIONS 100000

volatile int flag[2] = {0, 0};
volatile int turn;
int counter = 0;

void enter_region(int process)
{
    int other = 1 - process;

    flag[process] = 1;
    turn = other;

    while (flag[other] && turn == other)
        ;
}

void leave_region(int process)
{
    flag[process] = 0;
}

void *thread_func(void *arg)
{
    int id = *(int *)arg;

    for (int i = 0; i < ITERATIONS; i++)
    {
        enter_region(id);

        /* Critical Section */
        counter++;

        leave_region(id);

        /* Remainder Section */
    }

    return NULL;
}

int main()
{
    pthread_t t1, t2;

    int id0 = 0;
    int id1 = 1;

    pthread_create(&t1, NULL, thread_func, &id0);
    pthread_create(&t2, NULL, thread_func, &id1);

    pthread_join(t1, NULL);
    pthread_join(t2, NULL);

    printf("Final Counter = %d\n", counter);
    printf("Expected      = %d\n", 2 * ITERATIONS);

    return 0;
}
/*
Initially Global Memory:

flag[0]=0
flag[1]=0

Thread 0 writes: CPU0 Store Buffer

flag[0]=1

Thread 1 writes: CPU1 Store Buffer

flag[1]=1

Before these updates are copied to global memory, each CPU looks at the other flag.

CPU0 still sees:	flag[1]=0

CPU1 still sees:	flag[0]=0

Both think:	"The other thread is not interested."

and both enter!

*/

/*

Peterson fails because modern multiprocessors 
do not guarantee sequential consistency 
for ordinary memory accesses. 
Writes may remain in store buffers or 
be observed in different orders by different processors. 
Cache coherence ensures eventual visibility, 
but Peterson requires stronger ordering guarantees than 
ordinary reads and writes provide.

*/

/*
Never implement mutual exclusion yourself using ordinary shared variables. 
Use synchronization primitives that provide atomicity and memory ordering guarantees.
*/

/*
1) Run on a single CPU core:

taskset -c 0 ./peterson

2) Run on a two CPU cores:

taskset -c 0,1 ./peterson

*/

