class Buffer {

    private final int[] buffer = new int[5];

    private int count = 0;
    private int in = 0;
    private int out = 0;

    // Producer
    public synchronized void produce(int item)
            throws InterruptedException {

        // Buffer is full
        while (count == buffer.length) {
            wait();
        }

        // Add item
        buffer[in] = item;
        in = (in + 1) % buffer.length;
        count++;

        System.out.println(
            "Produced: " + item +
            " | Buffer Count: " + count
        );

        // Notify waiting consumer(s)
        notifyAll();
    }

    // Consumer
    public synchronized int consume()
            throws InterruptedException {

        // Buffer is empty
        while (count == 0) {
            wait();
        }

        // Remove item
        int item = buffer[out];
        out = (out + 1) % buffer.length;
        count--;

        System.out.println(
            "Consumed: " + item +
            " | Buffer Count: " + count
        );

        // Notify waiting producer(s)
        notifyAll();

        return item;
    }
}


class Producer implements Runnable {

    private final Buffer buffer;

    Producer(Buffer buffer) {
        this.buffer = buffer;
    }

    @Override
    public void run() {

        try {

            for (int i = 1; i <= 10; i++) {

                buffer.produce(i);

                Thread.sleep(100);
            }

        } catch (InterruptedException e) {

            Thread.currentThread().interrupt();
        }
    }
}


class Consumer implements Runnable {

    private final Buffer buffer;

    Consumer(Buffer buffer) {
        this.buffer = buffer;
    }

    @Override
    public void run() {

        try {

            for (int i = 1; i <= 10; i++) {

                buffer.consume();

                Thread.sleep(150);
            }

        } catch (InterruptedException e) {

            Thread.currentThread().interrupt();
        }
    }
}


public class ProducerConsumer {

    public static void main(String[] args)
            throws InterruptedException {

        Buffer buffer = new Buffer();

        Thread producer =
            new Thread(new Producer(buffer), "Producer");

        Thread consumer =
            new Thread(new Consumer(buffer), "Consumer");

        producer.start();
        consumer.start();

        producer.join();
        consumer.join();

        System.out.println("Processing completed.");
    }
}
