#include <stdio.h>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>

/* ANSI Colors */
#define GREEN "\033[1;32m"
#define BLUE  "\033[1;34m"
#define RED   "\033[1;31m"
#define RESET "\033[0m"

#define BUFFER_SIZE 20
#define ITEMS 100

int buffer[BUFFER_SIZE];

int in = 0;
int out = 0;

/* Semaphores */
sem_t empty_slot;
sem_t full_slot;
sem_t mutex;

void *producer(void *arg)
{
    for (int item = 1; item <= ITEMS; item++)
    {
        sem_wait(&empty_slot);   // Wait for an empty_slot in the buffer
        sem_wait(&mutex);   // Enter critical section

        buffer[in] = item;  // Produce item

        printf(GREEN "Producer: Produced %d at buffer[%d]\n", item, in);

        in = (in + 1) % BUFFER_SIZE;

        sem_post(&mutex);   // Leave critical section
        sem_post(&full_slot);    // Increase number of full_slot slots
    }
    return NULL;
}

void *consumer(void *arg)
{
    for (int i = 0; i < ITEMS; i++)
    {
        sem_wait(&full_slot);    // Wait for a filled buffer slot
        sem_wait(&mutex);   // Enter critical section

        int item = buffer[out];     //Consume item

        printf(BLUE "Consumer: Consumed %d from buffer[%d]\n", item, out);

        out = (out + 1) % BUFFER_SIZE;

        sem_post(&mutex);   // Leave critical section
        sem_post(&empty_slot);   // Increase number of empty_slot 
    }

    return NULL;
}

int main()
{
    pthread_t producer_thread;
    pthread_t consumer_thread;

    sem_init(&empty_slot, 0, BUFFER_SIZE);  // Initially all buffer slots are empty.
    sem_init(&full_slot, 0, 0);             // Initially there are no produced items.
    sem_init(&mutex, 0, 1);                 // Initially critical section is available.

    pthread_create(&producer_thread, NULL, producer, NULL);
    pthread_create(&consumer_thread, NULL, consumer, NULL);

    pthread_join(producer_thread, NULL);
    pthread_join(consumer_thread, NULL);

    sem_destroy(&empty_slot);
    sem_destroy(&full_slot);
    sem_destroy(&mutex);

    return 0;
}
