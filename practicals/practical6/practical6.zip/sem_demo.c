#include <stdio.h>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>

sem_t semaphore;

void *worker(void *arg)
{
    int id = *(int *)arg;

    printf("Thread %d is waiting for the semaphore...\n", id);

    // Wait / acquire semaphore
    sem_wait(&semaphore);

    printf("Thread %d entered the critical section.\n", id);

    // Critical section
    sleep(2);

    printf("Thread %d is leaving the critical section.\n", id);

    // Signal / release semaphore
    sem_post(&semaphore);

    return NULL;
}

int main()
{
    pthread_t t1, t2;
    int id1 = 1, id2 = 2;

    // Initialize semaphore
    // 0 = shared between threads
    // 1 = initial value
    sem_init(&semaphore, 0, 1);

    // Create two threads
    pthread_create(&t1, NULL, worker, &id1);
    pthread_create(&t2, NULL, worker, &id2);

    // Wait for both threads
    pthread_join(t1, NULL);
    pthread_join(t2, NULL);

    // Destroy semaphore
    sem_destroy(&semaphore);

    return 0;
}

