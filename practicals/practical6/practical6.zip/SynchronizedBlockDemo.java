class Counter {

    private int count = 0;

    // Monitor object
    private final Object obj = new Object();

    public void increment() {

        synchronized (obj) {
            // Critical section
            count++;
            System.out.println(
                Thread.currentThread().getName()
                + " : " + count
            );
        }
    }

    public int getCount() {
        return count;
    }
}

public class SynchronizedBlockDemo {

    public static void main(String[] args)
            throws InterruptedException {

        Counter counter = new Counter();

        Thread t1 = new Thread(() -> {
            for (int i = 0; i < 5; i++) {
                counter.increment();
            }
        }, "Thread-1");

        Thread t2 = new Thread(() -> {
            for (int i = 0; i < 5; i++) {
                counter.increment();
            }
        }, "Thread-2");

        t1.start();
        t2.start();

        t1.join();
        t2.join();

        System.out.println(
            "Final Count = " + counter.getCount()
        );
    }
}

