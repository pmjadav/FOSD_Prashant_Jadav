#include <stdio.h>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>

/* Shared variables */
int shared_data = 100;
int read_count = 0;

/* Semaphores */
sem_t mutex;
sem_t rw_mutex;


/* ---------------- READER ---------------- */

void *reader(void *arg)
{
    int id = *(int *)arg;

    printf("Reader %d wants to read.\n", id);

    /*
     * TODO 1:
     * Protect read_count using mutex.
     *
     * Hint:
     * Use sem_wait() and sem_post().
     */

    /*
     * TODO 2:
     * If this is the FIRST reader,
     * prevent writers from accessing shared_data.
     *
     * Condition:
     *     read_count == 1
     */

    printf("Reader %d is reading shared_data = %d\n",
           id, shared_data);

    sleep(1);

    /*
     * TODO 3:
     * Decrease read_count safely.
     *
     * Hint:
     * Again protect read_count using mutex.
     */

    /*
     * TODO 4:
     * If this is the LAST reader,
     * allow writers to access shared_data.
     *
     * Condition:
     *     read_count == 0
     */

    return NULL;
}


/* ---------------- WRITER ---------------- */

void *writer(void *arg)
{
    int id = *(int *)arg;

    printf("Writer %d wants to write.\n", id);

    /*
     * TODO 5:
     * A writer must obtain exclusive access
     * to the shared resource.
     */

    shared_data += 10;

    printf("Writer %d modified shared_data = %d\n",
           id, shared_data);

    sleep(1);

    /*
     * TODO 6:
     * Release the shared resource so that
     * another writer or readers can proceed.
     */

    return NULL;
}


/* ---------------- MAIN ---------------- */

int main()
{
    pthread_t readers[3];
    pthread_t writers[2];

    int reader_id[3] = {1, 2, 3};
    int writer_id[2] = {1, 2};

    /*
     * TODO 7:
     * Initialize both semaphores.
     *
     * mutex    -> protects read_count
     * rw_mutex -> protects shared_data
     *
     * Think about their initial values.
     */


    /* Create reader threads */
    for (int i = 0; i < 3; i++)
    {
        pthread_create(&readers[i],
                       NULL,
                       reader,
                       &reader_id[i]);
    }

    /* Create writer threads */
    for (int i = 0; i < 2; i++)
    {
        pthread_create(&writers[i],
                       NULL,
                       writer,
                       &writer_id[i]);
    }


    /*
     * TODO 8:
     * Wait for all reader threads to finish.
     */

    /*
     * TODO 9:
     * Wait for all writer threads to finish.
     */


    /*
     * TODO 10:
     * Destroy both semaphores.
     */

    return 0;
}