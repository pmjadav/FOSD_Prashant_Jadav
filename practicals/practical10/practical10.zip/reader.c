#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>

#define FIFO_NAME "myfifo"

int main()
{
    int fd;
    char message[100];

    // Open FIFO for reading
    fd = open(FIFO_NAME, O_RDONLY);

    // Read message from FIFO
    read(fd, message, sizeof(message));

    printf("Reader: Message received: %s\n", message);

    close(fd);

    return 0;
}
