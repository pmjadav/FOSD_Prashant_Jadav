#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/stat.h>
#include <string.h>

#define FIFO_NAME "myfifo"

int main()
{
    int fd;
    char message[100];

    // Create FIFO
    mkfifo(FIFO_NAME, 0666);

    printf("Writer: Enter a message: ");
    fgets(message, sizeof(message), stdin);

    // Open FIFO for writing
    fd = open(FIFO_NAME, O_WRONLY);

    // Write message into FIFO
    write(fd, message, strlen(message) + 1);

    printf("Writer: Message sent successfully.\n");

    close(fd);

    return 0;
}
