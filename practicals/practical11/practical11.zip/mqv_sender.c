#include <stdio.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <string.h>

struct message {
    long msg_type;  // must be long and greater than zero
    char mtext[100];
};

int main() {
    key_t key = ftok("systemv_queue", 22);
    //Generates a unique IPC key
    // 22 - project id

    int msgid = msgget(key, 0666 | IPC_CREAT);
    // Creates a System V message queue if it doesn't exist.
    // Message queues are stored inside kerenel not on file system.

    struct message msg;

    msg.msg_type = 1;
    strcpy(msg.mtext, "Hello Receiver");

    msgsnd(msgid, &msg, sizeof(msg.mtext), 0);
    // flag = 0             => default blocking behaviour
    // flag = IPC_NOWAIT    => do not block if queue is full (fails, returns -1 and sets errno)

    printf("Message sent\n");

    return 0;

    // To remove message queue use msgid not the key e.g.
    // msgctl(msgid, IPC_RMID, NULL);
    // OR
    // ipcrm -q <msgid> on terminal

    // ipcs     => To view all types of IPCs
    // ipcs -q  => message queue
    // ipcs -s  => semaphore
    // ipcs -m  => share memory
}
