#include <stdio.h>
#include <sys/ipc.h>
#include <sys/msg.h>

struct message {
    long msg_type;
    char text[100];
};

int main() 
{
    key_t key = ftok("systemv_queue", 22);
    // 22 - project id

    int msgid = msgget(key, 0666 | IPC_CREAT);
    // Creates a unique message queue if it doesn't exist

    struct message msg;

    msgrcv(msgid, &msg, sizeof(msg.text), 1, 0);
    // Here waiting for msgtyp = 1
    // msgtyp = 0   => receive first message in queue
    // msgtyp = k   => first message with type-k
    // msgtyp = -k  => first message with lowest type <= k
    // msgflg = 0   => if no matching message exists wait
    // msgflg = IPC_NOWAIT  => if no message available, return -1 and set errno
    
    printf("Received: %s\n", msg.text);

    return 0;
}

