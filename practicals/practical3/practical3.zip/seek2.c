#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/stat.h>
#include <stdlib.h>

int main()
{
    int fd;
    char buffer[100];
    ssize_t bytes;

    fd = open("input.txt", O_RDONLY);

    bytes = read(fd, buffer, 20);
    buffer[bytes] = '\0';

    printf("%s\n\n", buffer);

    lseek(fd, -5, SEEK_CUR);

    bytes = read(fd, buffer, 20);
    buffer[bytes] = '\0';

    printf("%s\n\n", buffer);

    close(fd);

    return 0;
}
