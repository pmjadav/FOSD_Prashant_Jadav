#include <stdio.h>
#include <unistd.h>
#include <sys/stat.h>

int main()
{
    struct stat st;

    stat("/home/pmj/os/lab/lab03", &st);

    printf("\nFile size: %ld\n", st.st_size);

    if ((st.st_mode & S_IFMT) == S_IFREG) {
        printf("\nRegular File\n");
    }
    
    if ((st.st_mode & S_IFMT) == S_IFDIR) {
        printf("\nDirectory\n");
    }
    return 0;
}
