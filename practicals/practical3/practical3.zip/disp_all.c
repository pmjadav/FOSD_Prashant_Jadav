#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>

int main()
{
    int fd;
    int count;
    int buf[10];

    fd = open("test.txt", O_RDONLY);

    while ( (count = read(fd, buf, sizeof(buf))) > 0)
        write(1, buf, count);
    
    close(fd);

    return 0;
}

