#include <stdio.h>
#include <stdlib.h>
#include <sys/sysinfo.h>

int main() {
    struct sysinfo info;

    if (sysinfo(&info) != 0) {
        perror("sysinfo");
        return 1;
    }

    printf("========== System Information ==========\n");

    printf("Uptime              : %ld seconds\n", info.uptime);

    printf("Load Average (1 min): %.2f\n", info.loads[0] / 65536.0);
    printf("Load Average (5 min): %.2f\n", info.loads[1] / 65536.0);
    printf("Load Average (15 min): %.2f\n", info.loads[2] / 65536.0);

    printf("\nMemory Information\n");
    printf("Total RAM           : %lu MB\n",
           (info.totalram * info.mem_unit) / (1024 * 1024));
    printf("Free RAM            : %lu MB\n",
           (info.freeram * info.mem_unit) / (1024 * 1024));
    printf("Shared RAM          : %lu MB\n",
           (info.sharedram * info.mem_unit) / (1024 * 1024));
    printf("Buffer RAM          : %lu MB\n",
           (info.bufferram * info.mem_unit) / (1024 * 1024));

    printf("\nSwap Information\n");
    printf("Total Swap          : %lu MB\n",
           (info.totalswap * info.mem_unit) / (1024 * 1024));
    printf("Free Swap           : %lu MB\n",
           (info.freeswap * info.mem_unit) / (1024 * 1024));

    printf("\nProcesses\n");
    printf("Current Processes   : %u\n", info.procs);

    printf("\nHigh Memory         : %lu MB\n",
           (info.totalhigh * info.mem_unit) / (1024 * 1024));
    printf("Free High Memory    : %lu MB\n",
           (info.freehigh * info.mem_unit) / (1024 * 1024));

    printf("========================================\n");

    return 0;
}

